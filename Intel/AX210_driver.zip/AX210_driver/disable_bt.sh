#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	exit 1
fi

sudo echo -e 'blacklist btusb\nblacklist bluetooth' > /etc/modprobe.d/bluetooth.conf

echo "Done."
echo "Please reboot the system to disable the Bluetooth"

