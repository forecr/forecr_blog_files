#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	exit 1
fi

sudo rm /lib/firmware/iwlwifi-ty-a0-gf-a0.pnvm
sudo rm /lib/firmware/iwlwifi-ty-a0-gf-a0-59.ucode
echo "Unnecessary files removed"

sudo mv iwlwifi-ty-a0-gf-a0-59.ucode /lib/firmware
echo "New AX210 driver added"

echo "Done."

