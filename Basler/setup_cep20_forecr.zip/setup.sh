#!/bin/bash

set -e

THISDIR=$(realpath `dirname $0`)

if [ $(id -u) -ne 0 ]; then
    echo "This must be run as root" >&2
    exit 1
fi

info() {
    echo ""
    echo -e "\e[34m>>>\e[0m ${@}"
}

try_uninstall_deb() {
    local package=$1

    # is the package known?
    local res=$(dpkg-query --list ${package} 2>/dev/null)
    if [ -z "${res}" ]; then
        return
    fi

    # is the package fully removed?
    if [ $(dpkg-query --show --showformat='${Status}' ${package} 2>/dev/null | grep -c 'not-install') -eq 1 ]; then
        return
    fi

    # no, try to remove it
    dpkg --purge ${package} || true
}


cd ${THISDIR}

info "Installing camera driver"
if [ $(dpkg-query --show --showformat='${Status}' dkms 2>/dev/null | grep -c 'install ok installed') -eq 0 ]; then
    read -t 10 -p " We have to install 'dkms', are you confirm? (y/n)" -n 1 -r
    echo
    if [[ ${REPLY} =~ ^[^Yy]$ ]]; then
        echo "We can't continue without dkms" >&2
        exit 1
    fi

    apt-get install --assume-yes --no-install-recommends dkms
fi
dpkg -i basler-camera-driver-dkms_*_arm64.deb


info "Installing GenTL Producers"
try_uninstall_deb basler-dart-bcon-mipi-gentl-producer
dpkg -i basler-daa2500-60mci*_arm64.deb
dpkg -i basler-daa4200-30mci*_arm64.deb


info "Installing pylon"
dpkg -i pylon_*_arm64.deb codemeter*_arm64.deb


info "CEP installed sucessfully. Please reboot the system."
