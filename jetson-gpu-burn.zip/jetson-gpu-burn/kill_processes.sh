killall gpu_burn
killall stress
