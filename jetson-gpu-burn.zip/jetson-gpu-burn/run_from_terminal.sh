stress --cpu $(($(nproc)-1)) &
./gpu_burn -tc 31104000 &
tegrastats
