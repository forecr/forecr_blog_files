#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

sudo jetson_clocks
stress --cpu $(($(nproc)-1)) &
./gpu_burn -tc 31104000 &
tegrastats
