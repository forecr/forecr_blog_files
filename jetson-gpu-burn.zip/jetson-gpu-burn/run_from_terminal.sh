#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

sudo jetson_clocks
mkdir -p logs
LOG_PREFIX=$(date +"%Y%m%d_%H%M%S")
stress --cpu $(($(nproc)-1)) -t 31104000 -v | tee logs/$LOG_PREFIX-stress.log &
./gpu_burn -tc 31104000 | tee logs/$LOG_PREFIX-gpu_burn.log &
tegrastats | tee logs/$LOG_PREFIX-tegrastats.log
