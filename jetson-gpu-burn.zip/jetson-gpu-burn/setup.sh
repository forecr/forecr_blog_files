make
sudo apt update
sudo apt-get install -y stress

