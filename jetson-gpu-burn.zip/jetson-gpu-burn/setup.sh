#!/bin/bash

echo "****************************"
echo "  1) Jetson AGX Thor"
echo "  2) Jetson AGX Orin, Jetson Orin NX, Jetson Orin Nano"
echo "  3) Jetson AGX Xavier, Jetson Xavier NX"
echo "  4) Jetson TX2"
echo "  5) Jetson Nano"
read -p "Select the correct Jetson type: " choice
echo ""

make clean

case $choice in
	1 ) 
		make COMPUTE=90
		;;
	2 ) 
		make COMPUTE=87
		;;
	3 ) 
		make COMPUTE=72
		;;
	4 ) 
		make COMPUTE=62
		;;
	5 ) 
		make COMPUTE=53
		;;
	* )
		echo "Wrong choice"
		exit 1
		;;
esac

if [ ! -f /usr/bin/stress ]; then
	sudo apt update
	sudo apt-get install -y stress
fi

echo "Done."

