#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

sudo jetson_clocks
mkdir -p logs
LOG_PREFIX=$(date +"%Y%m%d_%H%M%S")
xterm -e "stress --cpu $(($(nproc)-1)) -t 31104000 -v | tee logs/$LOG_PREFIX-stress.log" &
xterm -e "./gpu_burn -tc 31104000 | tee logs/$LOG_PREFIX-gpu_burn.log" &
tegrastats | tee logs/$LOG_PREFIX-tegrastats.log &
PID_TEGRASTAT_LOG=$!

LOOP_FLAG=true
echo "Press 'q' to quit"
while $LOOP_FLAG
do
	read -n 1 -s -r KEY
	case $KEY in
		q|Q)
			echo "Quitting"
			killall gpu_burn
			killall stress
			sleep 10
			kill $PID_TEGRASTAT_LOG
			LOOP_FLAG=false
			;;
		*)
			echo "Invalid input. You can press 'q' to quit"
			;;
	esac
done

echo "Done."
