#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

sudo jetson_clocks
xterm -e stress --cpu $(($(nproc)-1)) &
xterm -e ./gpu_burn -tc 31104000 &
tegrastats
