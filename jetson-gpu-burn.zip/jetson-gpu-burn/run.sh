xterm -e stress --cpu $(($(nproc)-1)) &
xterm -e ./gpu_burn -tc 31104000 &
tegrastats  
