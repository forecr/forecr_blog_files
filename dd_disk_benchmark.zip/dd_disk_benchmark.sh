#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

DISK_DIR=$1
FILE_SIZE_MB=1024
FILE_NAME=testfile
LOG_PREFIX=$(date +"%Y%m%d_%H%M%S")
LOG_FILE=dd_disk_bench_$LOG_PREFIX.log

if [ ! -d "$DISK_DIR" ]; then
	# If the storage is not mounted, print an error message and exit
	echo "Error: Storage is not mounted at $DISK_DIR. Please mount it and try again."
	exit 1
fi

if (( FILE_SIZE_MB > $(df -B MB $DISK_DIR | awk 'NR==2 {gsub(/MB/,""); print $4}' | bc) )); then
	echo "Current free space (MB): $(df -B MB $DISK_DIR | awk 'NR==2 {gsub(/MB/,""); print $4}' | bc)"
	echo "Please increase it to $FILE_SIZE_MB first."
	exit 1
fi

echo "System time: $(date)" > $LOG_FILE
echo "#####################" >> $LOG_FILE
echo "Hardware Info: $(lshw -c system)" >> $LOG_FILE
echo "#####################" >> $LOG_FILE
echo "Block devices:" >> $LOG_FILE
lsblk >> $LOG_FILE
echo "" >> $LOG_FILE
parted -l >> $LOG_FILE
echo "#####################" >> $LOG_FILE
echo "Disk Info:" >> $LOG_FILE
df -HT $DISK_DIR >> $LOG_FILE
parted $(df $DISK_DIR | awk 'NR==2 {print $1}') print >> $LOG_FILE
echo "#####################" >> $LOG_FILE
echo "File: $DISK_DIR/$FILE_NAME ($FILE_SIZE_MB MB)" >> $LOG_FILE
sync

# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

echo "Writing $FILE_NAME ($FILE_SIZE_MB MB) to $DISK_DIR ..."

{ time dd if=/dev/zero of=$DISK_DIR/$FILE_NAME bs=1M count=$FILE_SIZE_MB oflag=dsync; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > write_time.txt

WRITE_TIME_RAW=$(cat write_time.txt)
WRITE_TIME_MINUTES=$(echo $WRITE_TIME_RAW | awk -Fm '{print $1}')
WRITE_TIME_SECONDS=$(echo $WRITE_TIME_RAW | awk -Fm '{print $2}' | awk -Fs '{print $1}')
WRITE_TIME=$(echo "$WRITE_TIME_MINUTES * 60 + $WRITE_TIME_SECONDS" | bc)
WRITE_SPEED=$(echo "$FILE_SIZE_MB / $WRITE_TIME" | bc)

echo "Write speed: $WRITE_SPEED MB/s"
echo "Write speed: $WRITE_SPEED MB/s ($FILE_SIZE_MB MB / $WRITE_TIME seconds)" >> $LOG_FILE

# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

echo "Reading $FILE_NAME ($FILE_SIZE_MB MB) from $DISK_DIR ..."

{ time dd if=$DISK_DIR/$FILE_NAME of=/dev/null bs=1M count=$FILE_SIZE_MB; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > read_time.txt

READ_TIME_RAW=$(cat read_time.txt)
READ_TIME_MINUTES=$(echo $READ_TIME_RAW | awk -Fm '{print $1}')
READ_TIME_SECONDS=$(echo $READ_TIME_RAW | awk -Fm '{print $2}' | awk -Fs '{print $1}')
READ_TIME=$(echo "$READ_TIME_MINUTES * 60 + $READ_TIME_SECONDS" | bc)
READ_SPEED=$(echo "$FILE_SIZE_MB / $READ_TIME" | bc)

echo "Read speed: $READ_SPEED MB/s"
echo "Read speed: $READ_SPEED MB/s ($FILE_SIZE_MB MB / $READ_TIME seconds)" >> $LOG_FILE

rm write_time.txt
rm read_time.txt
rm $DISK_DIR/$FILE_NAME
chmod 666 $LOG_FILE

echo "Done."
