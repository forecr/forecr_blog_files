#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

DISK_DIR=$1
FILE_SIZE_MB=1024
FILE_NAME=testfile

if [ ! -d "$DISK_DIR" ]; then
	# If the storage is not mounted, print an error message and exit
	echo "Error: Storage is not mounted at $DISK_DIR. Please mount it and try again."
	exit 1
fi

dd if=/dev/zero of=$DISK_DIR/$FILE_NAME bs=1M count=$FILE_SIZE_MB 2> /dev/null

# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

echo "Writing $FILE_NAME ($FILE_SIZE_MB MB) to $DISK_DIR ..."

{ time dd if=/dev/zero of=$DISK_DIR/$FILE_NAME bs=1M count=$FILE_SIZE_MB oflag=dsync; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > write_time.txt

WRITE_TIME_RAW=$(cat write_time.txt)
WRITE_TIME_MINUTES=$(echo $WRITE_TIME_RAW | awk -Fm '{print $1}')
WRITE_TIME_SECONDS=$(echo $WRITE_TIME_RAW | awk -Fm '{print $2}' | awk -Fs '{print $1}')
WRITE_TIME=$(echo "$WRITE_TIME_MINUTES * 60 + $WRITE_TIME_SECONDS" | bc)
WRITE_SPEED=$(echo "$FILE_SIZE_MB / $WRITE_TIME" | bc)

echo "Write speed: $WRITE_SPEED MB/s"


# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

echo "Reading $FILE_NAME ($FILE_SIZE_MB MB) from $DISK_DIR ..."

{ time dd if=$DISK_DIR/$FILE_NAME of=/dev/null bs=1M count=$FILE_SIZE_MB; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > read_time.txt

READ_TIME_RAW=$(cat read_time.txt)
READ_TIME_MINUTES=$(echo $READ_TIME_RAW | awk -Fm '{print $1}')
READ_TIME_SECONDS=$(echo $READ_TIME_RAW | awk -Fm '{print $2}' | awk -Fs '{print $1}')
READ_TIME=$(echo "$READ_TIME_MINUTES * 60 + $READ_TIME_SECONDS" | bc)
READ_SPEED=$(echo "$FILE_SIZE_MB / $READ_TIME" | bc)

echo "Read speed: $READ_SPEED MB/s"

rm write_time.txt
rm read_time.txt
rm $DISK_DIR/$FILE_NAME

echo "Done."
