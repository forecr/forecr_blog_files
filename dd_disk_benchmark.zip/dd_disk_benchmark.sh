#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

DISK_DIR=$1

if [ ! -d "$DISK_DIR" ]; then
	# If the storage is not mounted, print an error message and exit
	echo "Error: Storage is not mounted at $DISK_DIR. Please mount it and try again."
	exit 1
fi

dd if=/dev/zero of=$DISK_DIR/testfile bs=1M count=1024 2> /dev/null

# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

{ time dd if=/dev/zero of=$DISK_DIR/testfile bs=1M count=1024 oflag=dsync; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > write_time.txt

write_time_raw=$(cat write_time.txt)
write_time_minutes=$(echo $write_time_raw | awk -Fm '{print $1}')
write_time_seconds=$(echo $write_time_raw | awk -Fm '{print $2}' | awk -Fs '{print $1}')
write_time=$(echo "$write_time_minutes * 60 + $write_time_seconds" | bc)
write_speed=$(echo "1024 / $write_time" | bc)

echo "Write speed: $write_speed MB/s"


# Clear the disk cache
sh -c 'echo 3 > /proc/sys/vm/drop_caches'

{ time dd if=$DISK_DIR/testfile of=/dev/null bs=1M count=1024; } 2>&1 | awk '/real/ {sub(/,/, "."); print $2}' > read_time.txt

read_time_raw=$(cat read_time.txt)
read_time_minutes=$(echo $read_time_raw | awk -Fm '{print $1}')
read_time_seconds=$(echo $read_time_raw | awk -Fm '{print $2}' | awk -Fs '{print $1}')
read_time=$(echo "$read_time_minutes * 60 + $read_time_seconds" | bc)
read_speed=$(echo "1024 / $read_time" | bc)

echo "Read speed: $read_speed MB/s"

rm write_time.txt
rm read_time.txt
rm $DISK_DIR/testfile

echo "Done."
