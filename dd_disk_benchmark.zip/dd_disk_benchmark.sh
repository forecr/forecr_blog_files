#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

STORAGE=$1

if [ -z "$STORAGE" ]
then
	echo "Storage Name is Empty!!"
	exit
fi

if [ ! -e "$STORAGE" ]; then
    echo "$STORAGE not exists!!"
	exit
fi

if [ "$(df | grep $STORAGE | wc -l)" != "0" ]
then
	echo "Storage has mounted. Please unmount it!!"
	exit
fi

if [ "$(df | grep /mnt | wc -l)" != "0" ]
then
	echo "/mnt has already used. Please unmount it!!"
	exit
fi

# Mount the storage to /mnt
sudo mount "$STORAGE" /mnt
cd /mnt

echo "Write Test"
sudo dd if=/dev/zero of=test.img bs=1G count=1 oflag=dsync
echo ""
echo "Read Test"
# flush buffers or disk caches #
#echo 3 | sudo tee /proc/sys/vm/drop_caches
dd if=test.img of=/dev/null bs=1G oflag=dsync
sudo rm test.img 

# Mount the storage from /mnt
cd ~
sudo umount /mnt

