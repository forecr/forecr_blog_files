#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

if [ $# -eq 0 ]; then
	echo "Please run as:"
	echo "sudo $0 NET_INTERFACE1 [NET_INTERFACE2 ...]"
	echo "Quitting ..."
	exit 1
fi

script_file=/etc/systemd/nv.sh

# Check all interfaces
correct_net=0
wrong_net=0
i=0
for net_interface in "$@"
do
	#(( i++ )); echo "$i. interface name: $net_interface"
	if [ "$(ip -o link show $net_interface | wc -l)" == "1" ]; then
		#echo "$net_interface found."
		correct_net=$(( correct_net + 1 ))
	else
		#echo "$net_interface could not found."
		(( wrong_net++ ))
	fi
done

# If all interfaces have not confirmed, exit
if (( wrong_net != 0 )); then
	echo "Quitting ..."
	exit 1
fi

# Check this patch has already applied.
if [ "$(cat $script_file | grep '#MAC address patch for network interfaces' | wc -l)" != "0" ]; then
	echo "This patch has already included."
	echo "Quitting ..."
	exit 1
fi

# Read the MAC addresses for each interface and include these settings in the script file
echo "#MAC address patch for network interfaces" >> $script_file
for net_interface in "$@"
do
	mac_addr=$(ip -o link show $net_interface | cut -d ' ' -f 20)
	echo "ifconfig $net_interface down" >> $script_file
	echo "ifconfig $net_interface hw ether $mac_addr" >> $script_file
	echo "ifconfig $net_interface up" >> $script_file
done

echo "Done."

