#!/bin/bash
if [ "$(whoami)" == "root" ] ; then
	echo "Please do not run as root"
	exit 1
fi

if [ "$(cat /etc/nv_tegra_release | grep -c '# R35 (release)')" == "1" ]; then
	echo "JetPack-5.x based system detected"
	mkdir -p ~/.config/autostart
	cp /usr/share/applications/vino-server.desktop ~/.config/autostart/.
else
	cd /usr/lib/systemd/user/graphical-session.target.wants
	sudo ln -s ../vino-server.service ./.
fi

gsettings set org.gnome.Vino prompt-enabled false
gsettings set org.gnome.Vino require-encryption false

# Replace nvidia with your desired password
gsettings set org.gnome.Vino authentication-methods "['vnc']"
gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)

if [ "$(cat /etc/nv_tegra_release | grep -c '# R35 (release)')" == "1" ]; then
	echo "VNC server configurations are complete. Rebooting now... Please keep the HDMI connected for each reboot"
else
	echo "VNC server configurations are complete. Rebooting now..."
fi

sleep 10
reboot

