#!/bin/bash

function apt_install_pkg {
	REQUIRED_PKG=$1
	PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $REQUIRED_PKG|grep "install ok installed")
	echo "Checking for $REQUIRED_PKG: $PKG_OK"
	if [ "" = "$PKG_OK" ]; then
		echo ""
		echo "$REQUIRED_PKG not found. Setting it up..."
		sudo apt-get --yes install $REQUIRED_PKG 

		PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $REQUIRED_PKG|grep "install ok installed")
		echo ""
		echo "Checking for $REQUIRED_PKG: $PKG_OK"

		if [ "" = "$PKG_OK" ]; then
			echo ""
			echo "$REQUIRED_PKG not installed. Please try again later"
			exit 1
		fi
	fi
}

function add_xorg_dummy_conf {
	# Check xserver-xorg-video-dummy installed
	apt_install_pkg 'xserver-xorg-video-dummy'

	# Check default config file saved as *.bkp
	if [ -f /etc/X11/xorg.conf.bkp ]; then
		echo "/etc/X11/xorg.conf.bkp exists."
	else
		cp /etc/X11/xorg.conf /etc/X11/xorg.conf.bkp
	fi

	# Check new dummy config file saved as *.dummy
	if [ -f /etc/X11/xorg.conf.dummy ]; then
		echo "/etc/X11/xorg.conf.dummy exists."
	else
		echo \
'Section "Device"
    Identifier "DummyDevice"
    Driver "dummy"
    VideoRam 256000
EndSection
 
Section "Screen"
    Identifier "DummyScreen"
    Device "DummyDevice"
    Monitor "DummyMonitor"
    DefaultDepth 24
    SubSection "Display"
        Depth 24
        Modes "1920x1080_60.0"
    EndSubSection
EndSection
 
Section "Monitor"
    Identifier "DummyMonitor"
    HorizSync 30-70
    VertRefresh 50-75
    ModeLine "1920x1080" 148.50 1920 2448 2492 2640 1080 1084 1089 1125 +Hsync +Vsync
EndSection
' > xorg.conf.dummy

		mv xorg.conf.dummy /etc/X11/
	fi

	# Check X11 config file patch included
	if [ "$(cat /etc/systemd/nv.sh | grep '#X11 config for VNC usage' | wc -l)" != "0" ]; then
		echo "This patch has already included."
	else
		echo '
#X11 config for VNC usage
if [ -f /etc/X11/xorg.conf.bkp ]; then
	if [ -f /etc/X11/xorg.conf.dummy ]; then
		if [ -c /dev/fb0 ]; then
			cp /etc/X11/xorg.conf.bkp /etc/X11/xorg.conf
			echo "Using default config file" > /tmp/x11_config_selection.txt
		else
			cp /etc/X11/xorg.conf.dummy /etc/X11/xorg.conf
			echo "Using 1080p dummy config file" > /tmp/x11_config_selection.txt
		fi
	else
		echo "/etc/X11/xorg.conf.dummy not found" > /tmp/x11_config_selection.txt
	fi
else
	echo "/etc/X11/xorg.conf.bkp not found" > /tmp/x11_config_selection.txt
fi
' >> /etc/systemd/nv.sh

		echo "X11 VNC patch included"
	fi
}


if [ "$(cat /etc/nv_tegra_release | grep -c '# R32 (release)')" == "1" ]; then
	echo "JetPack-4.x based system detected"
	if [ "$(whoami)" == "root" ] ; then
		echo "Please do not run as root"
		echo "Quitting ..."
		exit 1
	fi

	sudo ln -s /usr/lib/systemd/user/vino-server.service /usr/lib/systemd/user/graphical-session.target.wants/.

	export DISPLAY=:0.0
	gsettings set org.gnome.Vino prompt-enabled false
	gsettings set org.gnome.Vino require-encryption false

	# Replace nvidia with your desired password
	gsettings set org.gnome.Vino authentication-methods "['vnc']"
	gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)

elif [ "$(cat /etc/nv_tegra_release | grep -c '# R35 (release)')" == "1" ]; then
	echo "JetPack-5.x based system detected"
	if [ "$(whoami)" != "root" ] ; then
		echo "Please run as root"
		echo "Quitting ..."
		exit 1
	fi

	sudo -u $SUDO_USER mkdir -p /home/$SUDO_USER/.config/autostart
	sudo -u $SUDO_USER cp /usr/share/applications/vino-server.desktop /home/$SUDO_USER/.config/autostart/.

	add_xorg_dummy_conf

	export DISPLAY=:0.0
	sudo -u $SUDO_USER gsettings set org.gnome.Vino prompt-enabled false
	sudo -u $SUDO_USER gsettings set org.gnome.Vino require-encryption false

	# Replace nvidia with your desired password
	sudo -u $SUDO_USER gsettings set org.gnome.Vino authentication-methods "['vnc']"
	sudo -u $SUDO_USER gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)

elif [ "$(cat /etc/nv_tegra_release | grep -c '# R36 (release)')" == "1" ]; then
	echo "JetPack-6.x based system detected"
	if [ "$(whoami)" != "root" ] ; then
		echo "Please run as root"
		echo "Quitting ..."
		exit 1
	fi

	# Check vino installed
	apt_install_pkg 'vino'
	
	sudo -u $SUDO_USER mkdir -p /home/$SUDO_USER/.config/autostart
	sudo -u $SUDO_USER cp /usr/share/applications/vino-server.desktop /home/$SUDO_USER/.config/autostart/.

	add_xorg_dummy_conf

	export DISPLAY=:0.0
	sudo -u $SUDO_USER gsettings set org.gnome.Vino prompt-enabled false
	sudo -u $SUDO_USER gsettings set org.gnome.Vino require-encryption false

	# Replace nvidia with your desired password
	sudo -u $SUDO_USER gsettings set org.gnome.Vino authentication-methods "['vnc']"
	sudo -u $SUDO_USER gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)
else
	echo "Unable to find one of the compatible JetPack version"
	echo "Quitting ..."
	exit 1
fi

echo "VNC server configurations completed. Rebooting now..."

sleep 10
sudo reboot

