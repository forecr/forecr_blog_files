#!/bin/bash

if [ "$(cat /etc/nv_tegra_release | grep -c '# R32 (release)')" == "1" ]; then
	echo "JetPack-4.x based system detected"
	if [ "$(whoami)" == "root" ] ; then
		echo "Please do not run as root"
		echo "Quitting ..."
		exit 1
	fi

	sudo ln -s /usr/lib/systemd/user/vino-server.service /usr/lib/systemd/user/graphical-session.target.wants/.

	export DISPLAY=:0.0
	gsettings set org.gnome.Vino prompt-enabled false
	gsettings set org.gnome.Vino require-encryption false

	# Replace nvidia with your desired password
	gsettings set org.gnome.Vino authentication-methods "['vnc']"
	gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)

elif [ "$(cat /etc/nv_tegra_release | grep -c '# R35 (release)')" == "1" ]; then
	echo "JetPack-5.x based system detected"
	if [ "$(whoami)" != "root" ] ; then
		echo "Please run as root"
		echo "Quitting ..."
		exit 1
	fi

	sudo -u $SUDO_USER mkdir -p /home/$SUDO_USER/.config/autostart
	sudo -u $SUDO_USER cp /usr/share/applications/vino-server.desktop /home/$SUDO_USER/.config/autostart/.

	export DISPLAY=:0.0
	sudo -u $SUDO_USER gsettings set org.gnome.Vino prompt-enabled false
	sudo -u $SUDO_USER gsettings set org.gnome.Vino require-encryption false

	# Replace nvidia with your desired password
	sudo -u $SUDO_USER gsettings set org.gnome.Vino authentication-methods "['vnc']"
	sudo -u $SUDO_USER gsettings set org.gnome.Vino vnc-password $(echo -n 'nvidia'|base64)

else
	echo "Unable to find one of the compatible JetPack version"
	echo "Quitting ..."
	exit 1
fi

if [ "$(cat /etc/nv_tegra_release | grep -c '# R35 (release)')" == "1" ]; then
	echo "VNC server configurations are complete. Rebooting now... Please keep the HDMI connected for each reboot"
else
	echo "VNC server configurations are complete. Rebooting now..."
fi

sleep 10
sudo reboot

