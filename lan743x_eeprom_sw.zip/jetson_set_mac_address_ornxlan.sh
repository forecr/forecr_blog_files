#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

if [ $# -ne 0 ]; then
	echo "Please run as:"
	echo "sudo $0"
	echo "Quitting ..."
	exit 1
fi

script_file=/etc/systemd/nv.sh
net_list=(eth0 eth1)

# Check all interfaces
correct_net=0
wrong_net=0
i=0
for net_interface in "${net_list[@]}"
do
	#(( i++ )); echo "$i. interface name: $net_interface"
	if [ "$(ip -o link show $net_interface | wc -l)" == "1" ]; then
		#echo "$net_interface found."
		correct_net=$(( correct_net + 1 ))
	else
		#echo "$net_interface could not found."
		(( wrong_net++ ))
	fi
done

# If all interfaces have not confirmed, exit
if (( wrong_net != 0 )); then
	echo "Quitting ..."
	exit 1
fi

# Check this patch has already applied.
if [ "$(cat $script_file | grep '#MAC address patch for network interfaces' | wc -l)" != "0" ]; then
	echo "This patch has already included."
	echo "Quitting ..."
	exit 1
fi

# Read the MAC addresses for each interface and include these settings in the script file
declare -a net_mac_list
echo "#MAC address patch for network interfaces" >> $script_file
for net_interface in "${net_list[@]}"
do
	#echo $net_interface
	# Create the Network - MAC Address list
	index=$(cat /sys/class/net/$net_interface/device/uevent | grep DRIVER= | sed 's/DRIVER=//g')
	net_mac_list+=( "$index" )
	index=$(cat /sys/class/net/$net_interface/address)
	net_mac_list+=( "$index" )
	#echo "list ${net_mac_list[@]}"
	
done

# Include the MAC address configurator commands
echo "declare -a NET_MAC_LIST=(${net_mac_list[@]})" >> $script_file
echo "net_list=(eth0 eth1)" >> $script_file
# Find the correct network and its MAC address
echo "for net_interface in \"\${net_list[@]}\"" >> $script_file
echo "do" >> $script_file
echo "	index=\$(cat /sys/class/net/\$net_interface/device/uevent | grep DRIVER= | sed 's/DRIVER=//g')" >> $script_file
echo "	if [ \"\$index\" == \"\${NET_MAC_LIST[0]}\" ]; then" >> $script_file
echo "		ifconfig \$net_interface down" >> $script_file
echo "		ifconfig \$net_interface hw ether \${NET_MAC_LIST[1]}" >> $script_file
echo "		ifconfig \$net_interface up" >> $script_file
echo "	elif [ \"\$index\" == \"\${NET_MAC_LIST[2]}\" ]; then" >> $script_file
echo "		ifconfig \$net_interface down" >> $script_file
echo "		ifconfig \$net_interface hw ether \${NET_MAC_LIST[3]}" >> $script_file
echo "		ifconfig \$net_interface up" >> $script_file
echo "	fi" >> $script_file
echo "done" >> $script_file

echo "Done."

