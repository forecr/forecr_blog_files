#!/bin/bash
BOLD=$(tput bold)
NORMAL=$(tput sgr0)
RED='\033[0;31m'          # Red
GREEN='\033[0;32m'        # Green
COLOR_OFF='\033[0m'       # Text Reset

DOWNLOAD_FOLDER=$HOME/Downloads/nvidia/sdkm_downloads
JETPACK_FOLDER=$HOME/nvidia/nvidia_sdk

function download_path_selector {
	# Check host PC's folders for SDKManager's download & HW image folder
	INPUT_PATH=""
	echo "Default download folder: "
	echo "    ${BOLD}$DOWNLOAD_FOLDER${NORMAL}"
	echo "Type the download folder, or press [Enter] to use the default one."
	read -p "" INPUT_PATH
	if [ "" = "$INPUT_PATH" ]; then
		echo "selecting the default path."
	else
		DOWNLOAD_FOLDER=$INPUT_PATH
	fi
	if [ -d "$DOWNLOAD_FOLDER" ]; then
		echo -e "${GREEN}$DOWNLOAD_FOLDER folder exists${COLOR_OFF}"
	else
		echo -e "${RED}$DOWNLOAD_FOLDER folder does not exist${COLOR_OFF}"
		echo "Quitting ..."
		exit 1
	fi
	echo ""
}

function jetpack_path_selector {
	INPUT_PATH=""
	echo "Default JetPack folder: "
	echo "    ${BOLD}$JETPACK_FOLDER${NORMAL}"
	echo "Type the JetPack folder, or press [Enter] to use the default one."
	read -p "" INPUT_PATH
	if [ "" = "$INPUT_PATH" ]; then
		echo "selecting the default path."
	else
		JETPACK_FOLDER=$INPUT_PATH
	fi
	if [ -d "$JETPACK_FOLDER" ]; then
		echo -e "${GREEN}$JETPACK_FOLDER folder exists${COLOR_OFF}"
	else
		echo -e "${RED}$JETPACK_FOLDER folder does not exist${COLOR_OFF}"
		echo "Quitting ..."
		exit 1
	fi
}

# Generate the sdkm_gui_docker.sh file
touch sdkm_gui_docker.sh
echo "#!/bin/bash" > sdkm_gui_docker.sh
chmod +x sdkm_gui_docker.sh

# Ask container parameters
CONTAINER_COMMAND="docker run -it --ipc=host --privileged -v /dev/bus/usb:/dev/bus/usb/ --network host -v /tmp/.X11-unix:/tmp/.X11-unix"

read -p "Do you want to use the download folder from your host PC? [Y/n] " CHOICE
case $CHOICE in
	[Yy]* )
		download_path_selector
		echo "DOWNLOAD_FOLDER=$DOWNLOAD_FOLDER" >> sdkm_gui_docker.sh
		CONTAINER_COMMAND="$CONTAINER_COMMAND -v \$DOWNLOAD_FOLDER:/home/ubuntu/Downloads/nvidia/sdkm_downloads"
		;;
	* )
		echo "Selecting [n]"
		;;
esac

read -p "Do you want to use the JetPack folder from your host PC? [Y/n] " CHOICE
case $CHOICE in
	[Yy]* )
		jetpack_path_selector
		echo "JETPACK_FOLDER=$JETPACK_FOLDER" >> sdkm_gui_docker.sh
		CONTAINER_COMMAND="$CONTAINER_COMMAND -v \$JETPACK_FOLDER:/home/ubuntu/nvidia/nvidia_sdk"
		;;
	* )
		echo "Selecting [n]"
		;;
esac


# Check the SDK Manager DEB package downloaded
if [ $(ls sdkmanager_*.deb | wc -l) -eq "1" ]; then
	echo -e "${GREEN}$(ls sdkmanager_*.deb) found${COLOR_OFF}"
else
	echo -e "${RED}Please download only one Debian package from here: https://developer.download.nvidia.com/sdkmanager/redirects/sdkmanager-deb.html${COLOR_OFF}"
	echo "Quitting ..."
	exit 1
fi


# Build the base container
if [ $(docker --version | grep 'Docker' | wc -l) = "1" ]; then
	docker --version

	# Check the Docker container built before
	if [ $(docker images | grep sdkmanager_gui_base | wc -l) = "1" ]; then
		echo "Base image has already generated."
	else
		docker build -t sdkmanager_gui_base .
	fi
else
	echo "Quitting ..."
	exit 1
fi


# Include the rest of the parameters for sdkm_gui_docker.sh and CONTAINER_COMMAND
echo "xhost +" >> sdkm_gui_docker.sh
echo "echo \"After the Docker container started, please run 'sdkmanager'\"" >> sdkm_gui_docker.sh
echo "" >> sdkm_gui_docker.sh
echo "if [ \$(docker ps -a | grep 'sdkm_gui' | wc -l) = '1' ]; then" >> sdkm_gui_docker.sh
echo "	echo 'sdkm_gui container found'" >> sdkm_gui_docker.sh
echo "	read -p 'Do you want to use the recent container? [Y/n] ' CHOICE" >> sdkm_gui_docker.sh
echo "	case \$CHOICE in" >> sdkm_gui_docker.sh
echo "		[Yy]* )" >> sdkm_gui_docker.sh
echo "			docker restart sdkm_gui && docker attach sdkm_gui" >> sdkm_gui_docker.sh
echo "			;;" >> sdkm_gui_docker.sh
echo "		* )" >> sdkm_gui_docker.sh
echo "			echo 'Selecting [n]'" >> sdkm_gui_docker.sh
echo "			$CONTAINER_COMMAND -e DISPLAY=\$DISPLAY sdkmanager_gui_base" >> sdkm_gui_docker.sh
echo "			;;" >> sdkm_gui_docker.sh
echo "	esac" >> sdkm_gui_docker.sh
echo "else" >> sdkm_gui_docker.sh
echo "	$CONTAINER_COMMAND -e DISPLAY=\$DISPLAY --name sdkm_gui sdkmanager_gui_base" >> sdkm_gui_docker.sh
echo "fi" >> sdkm_gui_docker.sh
echo "" >> sdkm_gui_docker.sh


echo "Done."

