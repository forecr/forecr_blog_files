#!/bin/bash
BOLD=$(tput bold)
NORMAL=$(tput sgr0)
RED='\033[0;31m'          # Red
YELLOW='\033[0;33m'       # Yellow
GREEN='\033[0;32m'        # Green
COLOR_OFF='\033[0m'       # Text Reset

DOWNLOAD_FOLDER=$HOME/Downloads/nvidia/sdkm_downloads
JETPACK_FOLDER=$HOME/nvidia/nvidia_sdk
EXPORTED_FILE=sdkm_gui_docker_ubuntu22.sh

function download_path_selector {
	# Check host PC's folders for SDKManager's download & HW image folder
	INPUT_PATH=""
	echo "Default download folder: "
	echo "    ${BOLD}$DOWNLOAD_FOLDER${NORMAL}"
	echo "Type the download folder, or press [Enter] to use the default one."
	read -p "" INPUT_PATH
	if [ "" = "$INPUT_PATH" ]; then
		echo "selecting the default path."
	else
		DOWNLOAD_FOLDER=$INPUT_PATH
	fi
	if [ -d "$DOWNLOAD_FOLDER" ]; then
		echo -e "${GREEN}$DOWNLOAD_FOLDER folder exists${COLOR_OFF}"
	else
		echo -e "${RED}$DOWNLOAD_FOLDER folder does not exist${COLOR_OFF}"
		echo "Quitting ..."
		exit 1
	fi
	echo ""
}

function jetpack_path_selector {
	INPUT_PATH=""
	echo "Default JetPack folder: "
	echo "    ${BOLD}$JETPACK_FOLDER${NORMAL}"
	echo "Type the JetPack folder, or press [Enter] to use the default one."
	read -p "" INPUT_PATH
	if [ "" = "$INPUT_PATH" ]; then
		echo "selecting the default path."
	else
		JETPACK_FOLDER=$INPUT_PATH
	fi
	if [ -d "$JETPACK_FOLDER" ]; then
		echo -e "${GREEN}$JETPACK_FOLDER folder exists${COLOR_OFF}"
	else
		echo -e "${RED}$JETPACK_FOLDER folder does not exist${COLOR_OFF}"
		echo "Quitting ..."
		exit 1
	fi
}


# Build the base container
if [ $(docker --version | grep 'Docker' | wc -l) = "1" ]; then
	docker --version

	# Check the Docker container built before
	if [ $(docker images | grep sdkmanager_gui_base | grep 22.04 | wc -l) = "1" ]; then
		echo -e "${YELLOW}Base image has already generated${COLOR_OFF}"
	else
		# Check the SDK Manager DEB package downloaded
		if [ $(ls sdkmanager_*.deb | wc -l) -eq "1" ]; then
			echo -e "${GREEN}$(ls sdkmanager_*.deb) found${COLOR_OFF}"
		else
			echo -e "${RED}Please download only one Debian package from here: https://developer.nvidia.com/sdk-manager${COLOR_OFF}"
			echo "Quitting ..."
			exit 1
		fi

		docker build -f Dockerfile -t sdkmanager_gui_base:22.04 .
	fi
else
	echo -e "${RED}Docker has not installed yet${COLOR_OFF}"
	echo "Quitting ..."
	exit 1
fi


# Check the $EXPORTED_FILE file
if [ -f "$EXPORTED_FILE" ]; then
    echo -e "${YELLOW}$EXPORTED_FILE exists. If you want to generate it again, please remove it first.${COLOR_OFF}"
else
	# Generate the $EXPORTED_FILE file
	touch $EXPORTED_FILE
	echo "#!/bin/bash" > $EXPORTED_FILE
	chmod +x $EXPORTED_FILE

	# Ask container parameters
	CONTAINER_COMMAND="docker run -it --ipc=host --privileged -v /dev/bus/usb:/dev/bus/usb/ --network host -v /tmp/.X11-unix:/tmp/.X11-unix"

	read -p "Do you want to use the download folder from your host PC? [Y/n] " CHOICE
	case $CHOICE in
		[Yy]* )
			download_path_selector
			echo "DOWNLOAD_FOLDER=$DOWNLOAD_FOLDER" >> $EXPORTED_FILE
			CONTAINER_COMMAND="$CONTAINER_COMMAND -v \$DOWNLOAD_FOLDER:/home/ubuntu/Downloads/nvidia/sdkm_downloads"
			;;
		* )
			echo "Selecting [n]"
			;;
	esac

	read -p "Do you want to use the JetPack folder from your host PC? [Y/n] " CHOICE
	case $CHOICE in
		[Yy]* )
			jetpack_path_selector
			echo "JETPACK_FOLDER=$JETPACK_FOLDER" >> $EXPORTED_FILE
			CONTAINER_COMMAND="$CONTAINER_COMMAND -v \$JETPACK_FOLDER:/home/ubuntu/nvidia/nvidia_sdk"
			;;
		* )
			echo "Selecting [n]"
			;;
	esac


	# Include the rest of the parameters for $EXPORTED_FILE and CONTAINER_COMMAND
	echo "xhost +" >> $EXPORTED_FILE
	echo "echo \"After the Docker container started, please run 'sdkmanager'\"" >> $EXPORTED_FILE
	echo "" >> $EXPORTED_FILE
	echo "if [ \$(docker ps -a | grep 'sdkm_gui_ubuntu22' | wc -l) = '1' ]; then" >> $EXPORTED_FILE
	echo "	echo 'sdkm_gui_ubuntu22 container found'" >> $EXPORTED_FILE
	echo "	read -p 'Do you want to use the recent container? [Y/n] ' CHOICE" >> $EXPORTED_FILE
	echo "	case \$CHOICE in" >> $EXPORTED_FILE
	echo "		[Yy]* )" >> $EXPORTED_FILE
	echo "			docker restart sdkm_gui_ubuntu22 && docker attach sdkm_gui_ubuntu22" >> $EXPORTED_FILE
	echo "			;;" >> $EXPORTED_FILE
	echo "		* )" >> $EXPORTED_FILE
	echo "			echo 'Selecting [n]'" >> $EXPORTED_FILE
	echo "			$CONTAINER_COMMAND -e DISPLAY=\$DISPLAY sdkmanager_gui_base:22.04" >> $EXPORTED_FILE
	echo "			;;" >> $EXPORTED_FILE
	echo "	esac" >> $EXPORTED_FILE
	echo "else" >> $EXPORTED_FILE
	echo "	echo 'ATTENTION!!! This container prepared for passwordless user.'" >> $EXPORTED_FILE
	echo "	echo 'You can keep it safer by setting password for all users and replace the default /etc/sudoers file by:'" >> $EXPORTED_FILE
	echo "	echo '	$ sudo passwd ubuntu'" >> $EXPORTED_FILE
	echo "	echo '	$ sudo passwd root'" >> $EXPORTED_FILE
	echo "	echo '	$ sudo mv /etc/sudoers.bkp /etc/sudoers'" >> $EXPORTED_FILE
	echo "	$CONTAINER_COMMAND -e DISPLAY=\$DISPLAY --name sdkm_gui_ubuntu22 sdkmanager_gui_base:22.04" >> $EXPORTED_FILE
	echo "fi" >> $EXPORTED_FILE
	echo "" >> $EXPORTED_FILE

fi

echo "You can run: ${BOLD}./$EXPORTED_FILE${NORMAL}"
echo "Done."

