# DHCP Server Setup for Jetson

## Setup

### Static IP Configuration

Set static IP to the selected network interface. To do this, you can follow these steps below (you can use "nm-connection-editor", "nmtui" etc. as well)

Run the following command to view the available network interfaces:
```shell
$ nmcli device status
DEVICE  TYPE      STATE                   CONNECTION 
l4tbr0  bridge    connected (externally)  l4tbr0     
eth0    ethernet  unavailable             --         
can0    can       unmanaged               --         
can1    can       unmanaged               --         
usb0    ethernet  unmanaged               --         
usb1    ethernet  unmanaged               --         
lo      loopback  unmanaged               --         
```

Then, we select "eth0". Let's list the network profiles:
```shell
$ nmcli connection show
NAME                UUID                                  TYPE      DEVICE 
l4tbr0              8e6bfb64-ecc6-4df5-b9ba-685c8256a49c  bridge    l4tbr0 
Wired connection 1  7b7ec556-43de-37e3-8c65-a6c196d71dca  ethernet  --     
```

Let's modify "Wired connection 1" by setting "192.168.2.1" as static IP address:
```shell
sudo nmcli connection modify "Wired connection 1" ipv4.method manual ipv4.addresses 192.168.2.1/24 gw4 192.168.2.1
```


### DHCP Server Configuration

Run the following command to install required packages
```shell
sudo ./setup-dhcp-server.sh
```

Once the package setup completed, please configure "dhcpd.conf" and "isc-dhcp-server" for your use-case.

Then, run the following commands below:
```shell
sudo cp dhcpd.conf /etc/dhcp/dhcpd.conf
sudo dhcpd -t -cf /etc/dhcp/dhcpd.conf
sudo cp isc-dhcp-server /etc/default/isc-dhcp-server
sudo systemctl restart isc-dhcp-server
sudo systemctl enable isc-dhcp-server
```


## Debugging

View current leases
```shell
sudo cat /var/lib/dhcp/dhcpd.leases
```

Monitor lease assignments in real-time
```shell
sudo tail -f /var/log/syslog | grep dhcpd
```

Request new IP from DHCP
```shell
sudo dhclient -v eth0
```

