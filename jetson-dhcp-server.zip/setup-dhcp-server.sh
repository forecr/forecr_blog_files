#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

function apt_install_pkg {
	REQUIRED_PKG=$1
	PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $REQUIRED_PKG|grep "install ok installed")
	echo "Checking for $REQUIRED_PKG: $PKG_OK"
	if [ "" = "$PKG_OK" ]; then
		echo ""
		echo "$REQUIRED_PKG not found. Setting it up..."
		sudo apt-get --yes install $REQUIRED_PKG 

		PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $REQUIRED_PKG|grep "install ok installed")
		echo ""
		echo "Checking for $REQUIRED_PKG: $PKG_OK"

		if [ "" = "$PKG_OK" ]; then
			echo ""
			echo "$REQUIRED_PKG not installed. Please try again later"
			exit 1
		fi
	fi
}

apt_install_pkg 'ufw'
apt_install_pkg 'isc-dhcp-server'
apt_install_pkg 'nano'


if [ -e /etc/dhcp/dhcpd.conf.bak ]; then
	echo "DHCP server default config file already backed up"
else
	cp -p /etc/dhcp/dhcpd.conf /etc/dhcp/dhcpd.conf.bak
fi

#mv dhcpd.conf /etc/dhcp/dhcpd.conf
#dhcpd -t -cf /etc/dhcp/dhcpd.conf # Before restarting, you can validate your configuration file


if [ -e /lib/systemd/system/isc-dhcp-server.service.bak ]; then
	echo "ISC DHCP server service file already backed up"
else
	cp -p /lib/systemd/system/isc-dhcp-server.service /lib/systemd/system/isc-dhcp-server.service.bak

	# Apply 5s restart patch in the service file
	cp -p /lib/systemd/system/isc-dhcp-server.service.bak isc-dhcp-server.service
	# patch --dry-run isc-dhcp-server.service isc-dhcp-server-service.patch
	patch isc-dhcp-server.service isc-dhcp-server-service.patch
	mv isc-dhcp-server.service /lib/systemd/system/isc-dhcp-server.service
fi

if [ -e /etc/default/isc-dhcp-server.bak ]; then
	echo "ISC DHCP server default config file already backed up"
else
	cp -p /etc/default/isc-dhcp-server /etc/default/isc-dhcp-server.bak
fi

#mv isc-dhcp-server /etc/default/isc-dhcp-server

echo "Done."
