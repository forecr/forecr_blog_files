#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root"
	echo "Quitting ..."
	exit 1
fi

script_file=/etc/systemd/nv.sh

# Check this patch has already applied.
if [ "$(cat $script_file | grep '#Dual Ethernet Fix' | wc -l)" != "0" ]; then
	echo "This patch has already included."
	echo "Quitting ..."
	exit 1
fi

cp nv-dual-eth-check.sh /etc/systemd/
echo "#Dual Ethernet Fix" >> $script_file
echo "/etc/systemd/nv-dual-eth-check.sh" >> $script_file

echo "Done."
