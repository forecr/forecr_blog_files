#!/bin/bash

log_file=/tmp/nv-dual-eth-check-logs.txt

if [ "$(whoami)" != "root" ] ; then
	echo "Please run as root" >> $log_file
	echo "Quitting ..." >> $log_file
	exit 1
fi

function switch_net_names {
	temp_net_name=neweth0
	ip link set dev $1 down
	ip link set dev $2 down

	ip link set dev $1 name $temp_net_name
	ip link set dev $2 name $1
	ip link set dev $temp_net_name name $2

	ip link set dev $1 up
	ip link set dev $2 up
}

index=$(cat /sys/class/net/eth0/device/uevent | grep DRIVER= | sed 's/DRIVER=//g')
if [ "$index" != "r8168" ]; then
	echo "Renaming network interfaces"
	switch_net_names eth0 eth1
	echo "The interface name of eth0 & eth1 swapped" >> $log_file
fi

echo "Done."
